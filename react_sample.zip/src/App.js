import Report from "./report";
function App() {
  return (
    <div>
      <Report />
    </div>
  );
}

export default App;
